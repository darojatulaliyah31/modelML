const { db } = require('../firebase');  // Menggunakan db yang sudah diinisialisasi
const express = require('express');
const router = express.Router();

// Fungsi untuk mendapatkan rekomendasi tempat servis
async function getRecommendations(latitude, longitude) {
    const tempatServis = [];
    try {
        const snapshot = await db.collection('service-place').limit(3).get();

        // Pastikan snapshot ada dan bisa diiterasi
        if (!snapshot.empty) {
            snapshot.forEach(doc => {
                const data = doc.data();
                tempatServis.push({
                    id: doc.id,
                    name: data.name,
                    description: data.description,
                    image: data.image,
                    location: data.location,
                    rating: data.rating,
                    review: data.review,
                });
            });
        } else {
            console.log('No documents found');
        }
    } catch (error) {
        console.error('Error getting documents: ', error);
        throw error; // Re-throw error agar dapat ditangani oleh pemanggil
    }

    return tempatServis;
}

// Menambahkan route untuk mendapatkan rekomendasi
router.get('/', async (req, res) => {
  const { latitude, longitude } = req.query;
  if (!latitude || !longitude) {
    return res.status(400).json({ error: "Latitude and Longitude are required" });
  }

  try {
    const recommendations = await getRecommendations(latitude, longitude);
    res.status(200).json({ recommendations });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// // Mengubah dari GET ke POST
// router.post('/', async (req, res) => {
//     const { latitude, longitude } = req.body; // Mengambil latitude dan longitude dari body request
//     if (!latitude || !longitude) {
//       return res.status(400).json({ error: "Latitude and Longitude are required" });
//     }
  
//     try {
//       const recommendations = await getRecommendations(latitude, longitude);
//       res.status(200).json({ recommendations });
//     } catch (error) {
//       res.status(500).json({ error: error.message });
//     }
//   });
  

module.exports = router;
