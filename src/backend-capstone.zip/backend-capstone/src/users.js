const express = require("express");
const session = require("express-session");
const passport = require("passport");
const { Strategy: GoogleStrategy } = require("passport-google-oauth20");

require("dotenv").config();
const router = express.Router();

module.exports = (db) => {
  const usersCollection = db.collection("users");

  // Middleware session setup
  router.use(
    session({
      secret: process.env.SESSION_SECRET || "default_secret_key",
      resave: false,
      saveUninitialized: true,
      cookie: { maxAge: 60 * 60 * 1000 }, // Session expire in 1 hour
    })
  );

  // Passport setup
  router.use(passport.initialize());
  router.use(passport.session());

  passport.serializeUser((user, done) => {
    done(null, user);
  });

  passport.deserializeUser((user, done) => {
    done(null, user);
  });

  // Google OAuth Strategy
  passport.use(
    new GoogleStrategy(
      {
        clientID: process.env.GOOGLE_CLIENT_ID,
        clientSecret: process.env.GOOGLE_CLIENT_SECRET,
        callbackURL: process.env.GOOGLE_CALLBACK_URL,
      },
      async (accessToken, refreshToken, profile, done) => {
        try {
          const email = profile.emails[0].value;

          // Check if user already exists in Firestore
          const userDoc = await usersCollection.doc(email).get();

          if (!userDoc.exists) {
            // Register user if not exists
            await usersCollection.doc(email).set({
              fullName: profile.displayName,
              email: email,
              phoneNumber: "",
              favorites: [],
            });
          }

          const user = { fullName: profile.displayName, email: email };
          return done(null, user);
        } catch (error) {
          return done(error, null);
        }
      }
    )
  );

  // Sign Up Route
  router.post("/signup", async (req, res) => {
    const { fullName, email, phoneNumber, password } = req.body;

    if (!fullName || !email || !phoneNumber || !password) {
      return res.status(400).json({ error: "All fields are required" });
    }

    try {
      const userDoc = await usersCollection.doc(email).get();
      if (userDoc.exists) {
        return res.status(400).json({ error: "User already exists" });
      }

      await usersCollection.doc(email).set({
        fullName,
        email,
        phoneNumber,
        password,
        favorites: [],
      });

      res.status(201).json({ message: "User registered successfully" });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  // Login with Google
  router.get(
    "/auth/google",
    passport.authenticate("google", { scope: ["profile", "email"] })
  );

  router.get(
    "/auth/google/callback",
    passport.authenticate("google", {
      failureRedirect: "/login",
    }),
    (req, res) => {
      req.session.user = req.user; // Save user to session
      res.status(200).json({ message: "Login successful", user: req.user });
    }
  );

  // Logout Route
  router.post("/logout", (req, res) => {
    if (!req.session.user) {
      return res.status(400).json({ error: "User is not logged in" });
    }

    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Failed to log out" });
      }
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  // Protected Route Example
  const authenticateSession = (req, res, next) => {
    if (!req.session.user) {
      return res.status(401).json({ error: "Access denied, not logged in" });
    }
    next();
  };

  router.get("/favorites", authenticateSession, async (req, res) => {
    try {
      const userDoc = await usersCollection.doc(req.session.user.email).get();

      if (!userDoc.exists) {
        return res.status(404).json({ error: "User not found" });
      }

      res.status(200).json({ favorites: userDoc.data().favorites });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  return router;
};
