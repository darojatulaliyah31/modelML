const admin = require("firebase-admin");
const serviceAccount = require("./serviceAccountKey.json");

// Cek apakah sudah diinisialisasi sebelumnya
if (admin.apps.length === 0) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

const db = admin.firestore();

module.exports = { db };  // Pastikan ini yang Anda ekspor
